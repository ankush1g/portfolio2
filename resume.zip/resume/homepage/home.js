
document.addEventListener('DOMContentLoaded',(event)=>{
    let text=["Ankush Garg" , "Full Stack Developer" , "Bussiness Man"]
    let count=0;
    let index=0;
    let currentLetter='';
    let letter='';

    (function type(){
        if(count==text.length){
            count=0;
        }

        currentLetter=text[count];

        letter=currentLetter.slice(0,++index);
        // console.log(letter);

        const h1=document.querySelector('.home .left h1');
        h1.textContent=letter;

        if(letter.length==currentLetter.length){
            count++;
            index=0;
            setTimeout(type,2000);
        }
        else{
            setTimeout(type,100);
        }
    }())
})